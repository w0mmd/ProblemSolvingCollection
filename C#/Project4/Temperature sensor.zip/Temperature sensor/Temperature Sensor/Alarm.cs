﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temperature_Sensor
{
    internal class Alarm
    {
        private int AlarmValue {  get; set; }

        public Alarm(int AlarmTemp)
        {
           AlarmValue = AlarmTemp;
        }

        public void SetAlarm(int NewAlarmValue)
        {
            AlarmValue = NewAlarmValue;
        }

        public void FireAlarm(object sender, TempArgs args)
        {
            if(args.Temperature >  AlarmValue)
            {
                Console.WriteLine($"Take care, Temperature {args.Temperature} is higher than {AlarmValue}");
            }
        }
    }
}
