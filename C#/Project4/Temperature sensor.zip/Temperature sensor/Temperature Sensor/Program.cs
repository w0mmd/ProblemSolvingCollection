﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temperature_Sensor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the temprature system\n");

            Sensor sensor = new Sensor();
            Display display = new Display();
            Alarm alarm = new Alarm(50);

            sensor.SensorChnage += display.ShowTemperature;
            sensor.SensorChnage += alarm.FireAlarm;

            while (true)
            { 
            Console.WriteLine("1. Set the temprature.");
            Console.WriteLine("2. Set alarm value.");
            Console.WriteLine("3. Exit.");

            var result = Console.ReadLine();

                switch (result)
                {
                    case "1":
                        Console.WriteLine("Enter the temperature:");
                        var temp = Console.ReadLine();
                        int TempIntValue = Convert.ToInt32(temp);
                        sensor.ChangeTemperature(TempIntValue);
                        break;
                    case "2":
                        Console.WriteLine("Enter alarm value:");
                        var alarmString = Console.ReadLine();
                        int alarmValue = Convert.ToInt32(alarmString);
                        alarm.SetAlarm(alarmValue);
                        break;
                    case "3":
                        return;
                    default:
                        Console.WriteLine("Wrong input, enter a valid value...");
                        break;
                }
            }


        }
    }
}
