﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temperature_Sensor
{
    internal class Display
    {
        public void ShowTemperature(object sender, TempArgs args)
        {
            Console.WriteLine("The temperature is set to {0}", args.Temperature);
        }

    }
}
