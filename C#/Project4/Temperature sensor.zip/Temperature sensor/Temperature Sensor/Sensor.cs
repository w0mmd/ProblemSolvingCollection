﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temperature_Sensor
{
    internal class Sensor
    {
        public event EventHandler<TempArgs> SensorChnage;
        private int CurrentTemperature {  get; set; }

        public void ChangeTemperature(int NewTemperature)
        {
            CurrentTemperature = NewTemperature;
            SensorChnage.Invoke(this, new TempArgs(NewTemperature));
        }
    }
}
