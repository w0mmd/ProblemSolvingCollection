﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentSystemGrading
{
    internal class GradingSystem
    {
        public void DisplayGradingInfo(List<Student> students,
            Func<List<int>, double> CalculateAverage, 
            Predicate<double> CheckIfPassed,
            Action<Student, double, bool> DisplayData) 
        {
            foreach (var student in students)
            {
               double averageGrades =  CalculateAverage(student.grades);
                bool IsStudentPassed = CheckIfPassed(averageGrades);
                DisplayData.Invoke(student, averageGrades, IsStudentPassed);
            }

        }
    }
}
