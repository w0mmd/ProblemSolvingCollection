﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace StudentSystemGrading
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Student> students = new List<Student>();

            while (true)
            {
                Console.WriteLine("Welcome to the grading system\n");
                Console.WriteLine("Enter your name or 'done' when finished:");
                string StudentName = Console.ReadLine();

                if(StudentName == "done")
                {
                    break;
                }

                List<int> StudentsGrades = new List<int>();
                Console.WriteLine("Enter you grades (5 subject):");
                for(int i = 0; i < 5; i++)
                {
                    int Grades = int.Parse(Console.ReadLine());
                    StudentsGrades.Add(Grades);
                }

                Student student = new Student();
                student.Name = StudentName;
                student.grades = StudentsGrades;
                students.Add(student);
                Console.WriteLine($"A new student is added to the system with name {student.Name} and total grades {student.grades.Count}");
            }

           GradingSystem gradingSystem = new GradingSystem();
            gradingSystem.DisplayGradingInfo(students, GetAverageType01, CheckIfStudentPassed, DisplayData);

        }

        private static void DisplayData(Student student, double average, bool IsPassed)
        {
            string status = "Passed";

            if (!IsPassed)
            {
                status = "Failed";
            }

            Console.WriteLine($"The student name is {student.Name} and " +
                $"the average grade is {average}" +
                $"and the student is {status}");
        }

        private static bool CheckIfStudentPassed(double average)
        {
            if(average >= 30)
            {
                return true;
            }
            return false;
        }

        private static double GetAverageType01(List<int> grades)
        {
            return grades.Sum() / grades.Count;
        }
    }
}
