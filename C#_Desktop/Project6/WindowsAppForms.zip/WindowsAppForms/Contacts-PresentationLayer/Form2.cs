﻿using ContactsBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contacts_PresentationLayer
{
    public partial class Form2 : Form
    {

        public enum enMode { AddMode = 0, UpdateMode = 1}
        private enMode Mode = enMode.AddMode;

        int _ContactID;
        clsContact _Contact;

        public Form2(int ContactID)
        {
            InitializeComponent();

            this._ContactID = ContactID;
            if(this._ContactID == -1)
                Mode = enMode.AddMode;
            else
                Mode = enMode.UpdateMode;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            _LoadData();
        }

        private void _FillCountryToComboBox()
        {
            DataTable dt = clsCountry.GetAllCountries();

            foreach(DataRow row in dt.Rows)
            {
                cbCountry.Items.Add(row["CountryName"]);
            }
        }

        private void _LoadData()
        {
            _FillCountryToComboBox();
            cbCountry.SelectedIndex = 0;

            if(Mode == enMode.AddMode)
            {
                lblMode.Text = "Add New Contact";
                _Contact = new clsContact();
                return;
            }

            _Contact = clsContact.Find(_ContactID);

            if(_Contact == null)
            {
                MessageBox.Show("Contact is not found...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
                return;
            }

            lblMode.Text = "Edit Contact = " + _ContactID;
            label9.Text = _ContactID.ToString();
            txtFirstName.Text = _Contact.FirstName;
            txtLastName.Text = _Contact.LastName;
            txtEmail.Text = _Contact.Email;
            txtPhone.Text = _Contact.Phone;
            textBox1.Text = _Contact.Address;
            dateTimePicker1.Value = _Contact.DateOfBirth;
            
            if(_Contact.ImagePath != "")
            {
                try
                {
                    pictureBox1.Load(_Contact.ImagePath);
                }
                catch 
                {
                    pictureBox1.Load("C:/Users/user/Desktop/WINDOWSAPP (2)/close.png");
                }
            }

            linkLabel2.Visible = (_Contact.ImagePath != "");

            cbCountry.SelectedIndex = cbCountry.FindString(clsCountry.Find(_Contact.CountryID).CountryName);

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int CountryID = clsCountry.Find(cbCountry.Text).ID;

            _Contact.CountryID = CountryID;
            _Contact.FirstName = txtFirstName.Text;
            _Contact.LastName = txtLastName.Text;
            _Contact.Email = txtEmail.Text;
            _Contact.Phone = txtPhone.Text;
            _Contact.Address = textBox1.Text; ;
            _Contact.DateOfBirth = dateTimePicker1.Value;

            if (pictureBox1.ImageLocation != null)
            {
                _Contact.ImagePath = pictureBox1.ImageLocation.ToString();
            }
            else
            {
                _Contact.ImagePath = "";
            }

            if (_Contact.Save())
            {
                MessageBox.Show("Saved successfully...", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Saved failed...", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            Mode = enMode.UpdateMode;
            lblMode.Text = "Edit Contact = " + _ContactID;
            label9.Text = _ContactID.ToString();

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.FilterIndex = 1;

            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string selectedPath = openFileDialog1.FileName;

                pictureBox1.Load(selectedPath);
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pictureBox1.ImageLocation = null;
            linkLabel2.Visible = false;
        }
    }
}
