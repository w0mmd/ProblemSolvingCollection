﻿using ContactsBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contacts_PresentationLayer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _Refresh();
        }

        private void _Refresh()
        {
           dataGridView1.DataSource =  clsContact.GetAllContacts();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            Form form = new Form2(-1);
            form.ShowDialog();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form form = new Form2((int)dataGridView1.CurrentRow.Cells[0].Value);
            form.ShowDialog();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure you want to delete this contact [" + dataGridView1.CurrentRow.Cells[0].Value + "]?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
            {
                if (clsContact.DeleteContact((int)dataGridView1.CurrentRow.Cells[0].Value))
                {
                    MessageBox.Show("Deleted successfully...", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Deletion failed...", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
            }
        }
    }
}
